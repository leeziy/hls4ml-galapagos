Include files copied from Xilinx Vivado HLS 2018.3, required to synthesize HLS stream
