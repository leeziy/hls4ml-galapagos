// Fixed CR#735958 per Steve's requirement
const STL_STRING hlslib_sysheader_files[] = {
""
};


